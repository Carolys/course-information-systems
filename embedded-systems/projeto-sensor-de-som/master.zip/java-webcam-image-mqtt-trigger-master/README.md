# java-webcam-image-mqtt-trigger
[JAVA] [IOT] WebCam Image Capture with MQTT Trigger

This is a test project and should not be consider as a state of the art code.
