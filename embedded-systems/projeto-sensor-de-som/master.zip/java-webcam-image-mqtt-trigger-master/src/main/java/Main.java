import com.github.sarxos.webcam.Webcam;
import org.eclipse.paho.client.mqttv3.*;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.imageio.ImageIO;
import javax.mail.*;
import javax.mail.internet.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Main {

    private static final String TOPICO = "TOPICO";
    private static final String SERVER_URI = "tcp://iot.eclipse.org:1883";
    private static final int LIMITE = 50;

    private static final String emailRemetente = "";
    private static final String senhaRemetente = "";

    private static final String emailsDestinatarios = "";

    public static void main(String[] args) {

        final Webcam webcam = Webcam.getDefault();
        if (webcam != null) {
            System.out.println("Webcam: " + webcam.getName());
            webcam.setViewSize(new Dimension(640, 480));
            webcam.open();
        } else {
            System.out.println("No webcam detected");
            return;
        }

        String publisherId = UUID.randomUUID().toString();

        try {

            IMqttClient publisher = new MqttClient(SERVER_URI, publisherId);

            MqttConnectOptions options = new MqttConnectOptions();
            options.setAutomaticReconnect(true);
            options.setCleanSession(true);
            options.setConnectionTimeout(10);
            publisher.connect(options);

            final CountDownLatch receivedSignal = new CountDownLatch(10);

            publisher.subscribe(TOPICO, new IMqttMessageListener() {

                public void messageArrived(String topic, MqttMessage msg) throws Exception {

                    System.out.println("Leitura recebida: " + msg.toString());

                    if (Integer.parseInt(msg.toString()) > LIMITE) {

                        BufferedImage imagem = webcam.getImage();

                        File file = new File("imagens/" + msg.toString() + "-" + System.currentTimeMillis() + ".png");

                        ImageIO.write(imagem, "PNG", file);

                        sendEmail(msg.toString(),file);

                    }

                    receivedSignal.countDown();

                }

            });

            receivedSignal.await(1, TimeUnit.MINUTES);

        } catch (MqttException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    private static void sendEmail(String limite, File imagem) throws AddressException {

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true"); //TLS

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(emailRemetente,
                                senhaRemetente);
                    }
                });

        /** Ativa Debug para sessão */
        session.setDebug(true);

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(emailRemetente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailsDestinatarios));
            message.setSubject("Leitura IOT");
            MimeMultipart multipart = new MimeMultipart("related");
            BodyPart messageBodyPart = new MimeBodyPart();
            String htmlText = "<H3>Leitura recebida: "+limite+"</H3><img src=\"cid:image\">";
            messageBodyPart.setContent(htmlText, "text/html");
            multipart.addBodyPart(messageBodyPart);
            messageBodyPart = new MimeBodyPart();
            DataSource fds = new FileDataSource(imagem.getAbsolutePath());
            messageBodyPart.setDataHandler(new DataHandler(fds));
            messageBodyPart.setHeader("Content-ID", "<image>");
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart);
            Transport.send(message);

            System.out.println("Email enviado");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }


    }


}
