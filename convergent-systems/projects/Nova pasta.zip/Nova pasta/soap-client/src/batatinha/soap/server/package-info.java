@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.soap.batatinha/")
package batatinha.soap.server;
