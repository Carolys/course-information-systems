package batatinha.soap;

import batatinha.soap.server.Calculadora;
import batatinha.soap.server.CalculadoraService;

public class Main {
	
	public static Calculadora calculadora;

	public static void main(String[] args) {
		
		calculadora = new CalculadoraService().getCalculadoraPort();
		
		int resultado = calculadora.soma(2,5);
		
		System.out.println("Resultado da soma: "+ resultado);
		

	}

}

