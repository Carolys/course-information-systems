package batatinha.soap.server;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

/**
 * Servico de calcular que ser� exposto as chamadas remotas via web service
 * @author Carol
 *
 */

@WebService
public class Calculadora {
	
	@WebMethod(operationName = "soma_inteiros")
	@WebResult(name = "resultado_soma")
	public int soma(
			@WebParam(name="a") int a,
			@WebParam(name="b") int b) {
		int result = a + b;
		System.out.println("Resultado de " + a + "+" + b + "� igual a " + result);
		return result;
	}
	
	@WebMethod(operationName = "subtrai_inteiros")
	@WebResult(name = "resultado_subtracao")
	public int subtrair(			
			@WebParam(name="a") int a,
			@WebParam(name="b") int b) {
		int result = a - b;
		System.out.println("Resultado de " + a + "-" + b + "� igual a " + result);
		return result;
	}
	
	@WebMethod(operationName = "multiplica_inteiros")
	@WebResult(name = "resultado_multiplicacao")
	public int multiplicar(			
			@WebParam(name="a") int a,
			@WebParam(name="b") int b) {
		int result = a * b;
		System.out.println("Resultado de " + a + "*" + b + "� igual a " + result);
		return result;
	}
	
	@WebMethod(operationName = "didide_inteiros")
	@WebResult(name = "resultado_divisao")
	public int dividir(			
			@WebParam(name="a") int a,
			@WebParam(name="b") int b) {
		if(b!=0) {
			int result = a / b;
			System.out.println("Resultado de " + a + "/" + b + "� igual a " + result);
			return result;
		}
		else {
			System.out.println("Jamais dividir�s por ZERO!");
			return 0;
		}
		

	}

}

