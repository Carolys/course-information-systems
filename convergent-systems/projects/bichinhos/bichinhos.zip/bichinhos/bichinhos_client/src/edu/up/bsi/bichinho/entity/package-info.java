@javax.xml.bind.annotation.XmlSchema(namespace = "http://entity.bichinho.bsi.up.edu/")
package edu.up.bsi.bichinho.entity;
