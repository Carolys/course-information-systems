
package edu.up.bsi.bichinho.entity;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the edu.up.bsi.bichinho.entity package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Bichinho_QNAME = new QName("http://entity.bichinho.bsi.up.edu/", "bichinho");
    private final static QName _ListaBichinhos_QNAME = new QName("http://entity.bichinho.bsi.up.edu/", "listaBichinhos");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: edu.up.bsi.bichinho.entity
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Bichinho }
     * 
     */
    public Bichinho createBichinho() {
        return new Bichinho();
    }

    /**
     * Create an instance of {@link ListaBichinhos }
     * 
     */
    public ListaBichinhos createListaBichinhos() {
        return new ListaBichinhos();
    }

    /**
     * Create an instance of {@link ArrayList }
     * 
     */
    public ArrayList createArrayList() {
        return new ArrayList();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Bichinho }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://entity.bichinho.bsi.up.edu/", name = "bichinho")
    public JAXBElement<Bichinho> createBichinho(Bichinho value) {
        return new JAXBElement<Bichinho>(_Bichinho_QNAME, Bichinho.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListaBichinhos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://entity.bichinho.bsi.up.edu/", name = "listaBichinhos")
    public JAXBElement<ListaBichinhos> createListaBichinhos(ListaBichinhos value) {
        return new JAXBElement<ListaBichinhos>(_ListaBichinhos_QNAME, ListaBichinhos.class, null, value);
    }

}
