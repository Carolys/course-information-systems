
package edu.up.bsi.bichinho.entity;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for listaBichinhos complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="listaBichinhos">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bichinhos" type="{http://entity.bichinho.bsi.up.edu/}bichinho" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "listaBichinhos", propOrder = {
    "bichinhos"
})
public class ListaBichinhos {

    protected List<Bichinho> bichinhos;

    /**
     * Gets the value of the bichinhos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the bichinhos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBichinhos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Bichinho }
     * 
     * 
     */
    public List<Bichinho> getBichinhos() {
        if (bichinhos == null) {
            bichinhos = new ArrayList<Bichinho>();
        }
        return this.bichinhos;
    }

}
