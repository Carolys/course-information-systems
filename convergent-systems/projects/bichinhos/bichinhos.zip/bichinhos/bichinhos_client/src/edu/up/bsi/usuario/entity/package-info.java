@javax.xml.bind.annotation.XmlSchema(namespace = "http://entity.usuario.bsi.up.edu/")
package edu.up.bsi.usuario.entity;
