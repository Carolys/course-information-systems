package edu.up.bsi.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;

import edu.up.bsi.bichinho.entity.Bichinho;
import edu.up.bsi.bichinho.entity.Buscar;
import edu.up.bsi.bichinho.entity.ListaBichinhos;
import edu.up.bsi.usuario.entity.ListaUsuarios;
import edu.up.bsi.usuario.entity.Login;
import edu.up.bsi.usuario.entity.Usuario;

public class Main {

	private static final String WS_URL = "http://localhost:9090/login?wsdl";
	private static final String WS_URL1 = "http://localhost:8080/buscar?wsdl";

	public static void main(String[] args) throws MalformedURLException {

		URL url = new URL(WS_URL);
		URL url1 = new URL(WS_URL1);

		QName qname = new QName("http://entity.usuario.bsi.up.edu/", "LoginImpService");
		QName qname1 = new QName("http://entity.bichinho.bsi.up.edu/", "BuscarImpService");

		Service service = Service.create(url, qname);
		Service service1 = Service.create(url1, qname1);
		Login login = service.getPort(Login.class);
		Buscar buscar = service1.getPort(Buscar.class);

		BindingProvider provider = (BindingProvider) login;

		Map<String, Object> req_ctx = provider.getRequestContext();

		req_ctx.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, WS_URL);

		Scanner teclado = new Scanner(System.in);
		String r = "S";
		String msg = "";
		int op = 0;
		Usuario user = new Usuario();
		Bichinho bichinho = new Bichinho();

		System.out.println("-----Login-----");
		Map<String, List<String>> headers = new HashMap<String, List<String>>();

		System.out.println("Insira seu id: ");
		user.setNome(teclado.next());
		headers.put("Username", Collections.singletonList(user.getNome()));
		System.out.println("Insira sua senha: ");
		user.setSenha(teclado.next());
		headers.put("Password", Collections.singletonList(user.getSenha()));

		req_ctx.put(MessageContext.HTTP_REQUEST_HEADERS, headers);

		msg = login.getMessageLogin();

		if (!msg.equalsIgnoreCase("n")) {

			System.out.println("\n" + msg);

			while (r.trim().equalsIgnoreCase("S")) {
				System.out.println("\n----Menu-----");
				System.out.println(" 1 - Listar todos os usu�rios");
				System.out.println(" 2 - Mostrar todos os seus dados");
				System.out.println(" 3 - Mostrar idade");
				System.out.println(" 4 - Mostrar cpf");
				System.out.println(" 5 - Mostrar telefone");
				System.out.println(" 6 - Mostrar cep");
				System.out.println(" 7 - Listar todos os bichinhos");
				System.out.println(" 8 - Mostrar todos os dados de um bichinho");
				System.out.println(" 9 - Mostrar a ra�a de um bichinho");
				System.out.println("10 - Mostrar a idade de um bichinho");
				System.out.println("11 - Mostrar o g�nero de um bichinho");
				System.out.println("12 - Mostrar a foto de um bichinho");
				System.out.println("13 - Mostrar o cep de um bichinho");
				System.out.println("14 - Mostrar o telefone de um bichinho");
				System.out.println("15 - Mostrar se o bichinho mora na mesma cidade\n");

				System.out.println("Escolha uma op��o: ");
				op = teclado.nextInt();

				switch (op) {
				case 1:
					ListaUsuarios lista = login.getAll();
					// List<Usuario> lista = (List<Usuario>) login.getAll();
					for (int u = 0; u < 5; u++) {
						System.out.println("Nome: " + lista.getUsuarios().get(u).getNome());
						System.out.println("Idade: " + lista.getUsuarios().get(u).getIdade());
						System.out.println("Cpf: " + lista.getUsuarios().get(u).getCpf());
						System.out.println("Telefone: " + lista.getUsuarios().get(u).getTelefone());
						System.out.println("Cep: " + lista.getUsuarios().get(u).getCep() + "\n");
					}

					System.out.println("\n");

					break;
				case 2:
					user = login.getTodosOsDados(user);
					System.out.println("\nSua idade �: " + user.getIdade());
					System.out.println("Seu cpf �: " + user.getCpf());
					System.out.println("Seu telefone �: " + user.getTelefone() + "\n");
					break;
				case 3:
					user.setIdade(login.getIdade(user));
					System.out.println("\nSua idade �: " + user.getIdade() + "\n");
					break;
				case 4:
					user.setCpf(login.getCpf(user));
					System.out.println("\nSeu cpf �: " + user.getCpf() + "\n");
					break;
				case 5:
					user.setTelefone(login.getTelefone(user));
					System.out.println("\nSeu telefone �: " + user.getTelefone() + "\n");
					break;
				case 6:
					user.setCep(login.getCep(user));
					System.out.println("\nSeu cep �: " + user.getCep() + "\n");
					break;
				case 7:
					ListaBichinhos listab = buscar.getAll();

					for (int u = 0; u < 5; u++) {
						
						System.out.println("Foto do bichinho: "+buscar.getImg());
						System.out.println("Nome: " + listab.getBichinhos().get(u).getNome());
						System.out.println("Ra�a: " + listab.getBichinhos().get(u).getRaca());
						System.out.println("Idade: " + listab.getBichinhos().get(u).getIdade());
						System.out.println("G�nero: " + listab.getBichinhos().get(u).getGenero());
						System.out.println("De: " + login.getCidade(listab.getBichinhos().get(u).getCep()));
						System.out.println("Telefone: " + listab.getBichinhos().get(u).getTelefone() + "\n");
					}

					System.out.println("\n");
					break;
				case 8:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho = buscar.getTodosOsDados(bichinho);
						System.out.println("\nFoto do bichinho: " + buscar.getImg());
						System.out.println("Seu nome �: " + bichinho.getNome());
						System.out.println("Sua ra�a �: " + bichinho.getRaca());
						System.out.println("Sua idade �: " + bichinho.getIdade());
						System.out.println("Seu g�nero �: " + bichinho.getGenero());
						System.out.println("� de: " + login.getCidade(buscar.getCep(bichinho)));
						System.out.println("Seu telefone �: " + bichinho.getTelefone() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 9:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho.setRaca(buscar.getRaca(bichinho));
						System.out.println("\nSua ra�a �: " + bichinho.getRaca() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 10:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho.setIdade(buscar.getIdade(bichinho));
						System.out.println("\nSua idade �: " + bichinho.getIdade() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 11:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho.setGenero(buscar.getGenero(bichinho));
						System.out.println("\nSeu g�nero �: " + bichinho.getGenero() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 12:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						System.out.println("\nFoto do bichinho: " + buscar.getImg() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 13:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho.setCep(buscar.getCep(bichinho));
						System.out.println("\nSeu cep �: " + bichinho.getCep() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 14:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());

					if (buscar.verificar(bichinho)) {
						bichinho.setTelefone(buscar.getTelefone(bichinho));
						System.out.println("\nSeu telefone �: " + bichinho.getTelefone() + "\n");
					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
					break;
				case 15:
					System.out.println("\nInsira o nome do bichinho: ");
					bichinho.setNome((teclado.next()).toLowerCase());
					//System.out.println(buscar.getCep(bichinho));
					//System.out.println(login.getCep(user));
					if (buscar.verificar(bichinho)) {
						if (login.validaCep(buscar.getCep(bichinho), login.getCep(user))) {
							System.out.println(
									"Yeey, voc�s moram na mesma cidade!\nTente ligar para o telefone, assim um bichinho vai ter a chance de ser mais feliz!");
						} else {
							System.out.println(
									"Infelizmente voc�s moram longe!:C\nVerifique a lista de bichinhos, voc� pode encontrar um bem pertinho de voc�!");
						}

					} else {
						System.out.println(
								"Bichinho n�o encontrado!:c\nVerifique se digitou o nome corretamente ou olhe a lista de bichinhos dispon�vel!");
					}
				default:

				}

				System.out.println("Deseja continuar? (s/n)");
				r = teclado.next();
			}
		} else {

			System.out.println("Usu�rio inv�lido brow! Tente de novo!");

		}
	}

}
