@javax.xml.bind.annotation.XmlSchema(namespace = "http://entity.bsi.up.edu/")
package edu.up.bsi.entity;
